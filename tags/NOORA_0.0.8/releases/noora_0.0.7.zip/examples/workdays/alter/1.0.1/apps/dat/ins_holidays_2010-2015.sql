-- feestdayen 2010
insert into holidays(day, year, description)
values(to_date('2010-01-01','yyyy-mm-dd'),'2010','Nieuwjaar');
insert into holidays(day, year, description)
values(to_date('2010-04-04','yyyy-mm-dd'),'2010','1e Paasdag');
insert into holidays(day, year, description)
values(to_date('2010-04-05','yyyy-mm-dd'),'2010','2e Paasdag');
insert into holidays(day, year, description)
values(to_date('2010-04-30','yyyy-mm-dd'),'2010','Koninginnedag');
insert into holidays(day, year, description)
values(to_date('2010-05-05','yyyy-mm-dd'),'2010','Bevrijdingsdag');
insert into holidays(day, year, description)
values(to_date('2010-05-13','yyyy-mm-dd'),'2010','Hemelvaartdag');
insert into holidays(day, year, description)
values(to_date('2010-05-23','yyyy-mm-dd'),'2010','1e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2010-05-24','yyyy-mm-dd'),'2010','2e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2010-12-25','yyyy-mm-dd'),'2010','1e Kerstdag');
insert into holidays(day, year, description)
values(to_date('2010-12-26','yyyy-mm-dd'),'2010','2e Kerstdag');
-- feestdayen 2011
insert into holidays(day, year, description)
values(to_date('2011-01-01','yyyy-mm-dd'),'2011','Nieuwjaar');
insert into holidays(day, year, description)
values(to_date('2011-04-24','yyyy-mm-dd'),'2011','1e Paasdag');
insert into holidays(day, year, description)
values(to_date('2011-04-25','yyyy-mm-dd'),'2011','2e Paasdag');
insert into holidays(day, year, description)
values(to_date('2011-04-30','yyyy-mm-dd'),'2011','Koninginnedag');
insert into holidays(day, year, description)
values(to_date('2011-06-02','yyyy-mm-dd'),'2011','Hemelvaartdag');
insert into holidays(day, year, description)
values(to_date('2011-06-12','yyyy-mm-dd'),'2011','1e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2011-06-13','yyyy-mm-dd'),'2011','2e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2011-12-25','yyyy-mm-dd'),'2011','1e Kerstdag');
insert into holidays(day, year, description)
values(to_date('2011-12-26','yyyy-mm-dd'),'2011','2e Kerstdag');
-- feestdayen 2012
insert into holidays(day, year, description)
values(to_date('2012-01-01','yyyy-mm-dd'),'2012','Nieuwjaar');
insert into holidays(day, year, description)
values(to_date('2012-04-08','yyyy-mm-dd'),'2012','1e Paasdag');
insert into holidays(day, year, description)
values(to_date('2012-04-09','yyyy-mm-dd'),'2012','2e Paasdag');
insert into holidays(day, year, description)
values(to_date('2012-04-30','yyyy-mm-dd'),'2012','Koninginnedag');
insert into holidays(day, year, description)
values(to_date('2012-05-17','yyyy-mm-dd'),'2012','Hemelvaartdag');
insert into holidays(day, year, description)
values(to_date('2012-05-27','yyyy-mm-dd'),'2012','1e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2012-05-28','yyyy-mm-dd'),'2012','2e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2012-12-25','yyyy-mm-dd'),'2012','1e Kerstdag');
insert into holidays(day, year, description)
values(to_date('2012-12-26','yyyy-mm-dd'),'2012','2e Kerstdag');
-- feestdayen 2013
insert into holidays(day, year, description)
values(to_date('2013-01-01','yyyy-mm-dd'),'2013','Nieuwjaar');
insert into holidays(day, year, description)
values(to_date('2013-03-31','yyyy-mm-dd'),'2013','1e Paasdag');
insert into holidays(day, year, description)
values(to_date('2013-04-01','yyyy-mm-dd'),'2013','2e Paasdag');
insert into holidays(day, year, description)
values(to_date('2013-04-30','yyyy-mm-dd'),'2013','Koninginnedag');
insert into holidays(day, year, description)
values(to_date('2013-05-09','yyyy-mm-dd'),'2013','Hemelvaartdag');
insert into holidays(day, year, description)
values(to_date('2013-05-19','yyyy-mm-dd'),'2013','1e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2013-05-20','yyyy-mm-dd'),'2013','2e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2013-12-25','yyyy-mm-dd'),'2013','1e Kerstdag');
insert into holidays(day, year, description)
values(to_date('2013-12-26','yyyy-mm-dd'),'2013','2e Kerstdag');
-- feestdayen 2014
insert into holidays(day, year, description)
values(to_date('2014-01-01','yyyy-mm-dd'),'2014','Nieuwjaar');
insert into holidays(day, year, description)
values(to_date('2014-04-20','yyyy-mm-dd'),'2014','1e Paasdag');
insert into holidays(day, year, description)
values(to_date('2014-04-21','yyyy-mm-dd'),'2014','2e Paasdag');
insert into holidays(day, year, description)
values(to_date('2014-04-30','yyyy-mm-dd'),'2014','Koninginnedag');
insert into holidays(day, year, description)
values(to_date('2014-05-29','yyyy-mm-dd'),'2014','Hemelvaartdag');
insert into holidays(day, year, description)
values(to_date('2014-06-08','yyyy-mm-dd'),'2014','1e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2014-06-09','yyyy-mm-dd'),'2014','2e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2014-12-25','yyyy-mm-dd'),'2014','1e Kerstdag');
insert into holidays(day, year, description)
values(to_date('2014-12-26','yyyy-mm-dd'),'2014','2e Kerstdag');
-- feestdayen 2015
insert into holidays(day, year, description)
values(to_date('2015-01-01','yyyy-mm-dd'),'2015','Nieuwjaar');
insert into holidays(day, year, description)
values(to_date('2015-04-05','yyyy-mm-dd'),'2015','1e Paasdag');
insert into holidays(day, year, description)
values(to_date('2015-04-06','yyyy-mm-dd'),'2015','2e Paasdag');
insert into holidays(day, year, description)
values(to_date('2015-04-30','yyyy-mm-dd'),'2015','Koninginnedag');
insert into holidays(day, year, description)
values(to_date('2015-05-05','yyyy-mm-dd'),'2015','Bevrijdingsdag');
insert into holidays(day, year, description)
values(to_date('2015-05-14','yyyy-mm-dd'),'2015','Hemelvaartdag');
insert into holidays(day, year, description)
values(to_date('2015-05-24','yyyy-mm-dd'),'2015','1e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2015-05-25','yyyy-mm-dd'),'2015','2e Pinksterdag');
insert into holidays(day, year, description)
values(to_date('2015-12-25','yyyy-mm-dd'),'2015','1e Kerstdag');
insert into holidays(day, year, description)
values(to_date('2015-12-26','yyyy-mm-dd'),'2015','2e Kerstdag');
