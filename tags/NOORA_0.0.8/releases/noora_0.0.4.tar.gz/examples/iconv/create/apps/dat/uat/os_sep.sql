insert into application_properties(id,name,value,description) 
values (application_properties_s.nextval,'os.sep','/','operating system seperator');
