begin
  validator.create_validate_table
    (p_table_name => 'sr_selection'
    ,p_validate_table_name => 'sr_selection_validate');
end;
/