alter table files_err add external_id varchar2(4000);
alter table files_err add records_ignored varchar2(4000);
