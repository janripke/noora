begin
	ut_run.run('UT_VALIDATOR');
end;
/
