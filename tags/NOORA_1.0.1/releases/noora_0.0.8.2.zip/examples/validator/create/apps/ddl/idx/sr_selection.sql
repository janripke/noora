create index sr_sn_stage_id_idx on sr_selection (stage_id) nologging tablespace ts_index;
