-- Create sequence 
create sequence FILES_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 6
increment by 1
nocache
order
;
