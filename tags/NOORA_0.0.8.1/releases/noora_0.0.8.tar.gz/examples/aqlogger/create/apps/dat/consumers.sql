begin
   --db_logger.create_consumer('TAB.USER_DATA.LOGTYPE_CODE=''DEBUG''');
   db_logger.create_consumer();
end;
/