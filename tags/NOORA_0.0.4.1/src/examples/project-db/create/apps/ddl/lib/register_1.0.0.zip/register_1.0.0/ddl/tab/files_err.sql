begin
  dbms_errlog.create_error_log('files','files_err');
end;
/
