insert into application_properties(id,name,value) values (application_properties_s.nextval,'logger.archive_period','28');
