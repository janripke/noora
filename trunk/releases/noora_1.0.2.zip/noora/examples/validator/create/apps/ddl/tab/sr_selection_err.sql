begin
  dbms_errlog.create_error_log('sr_selection','sr_selection_err');
end;
/