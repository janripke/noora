insert into application_properties(id,name,value,description) 
values (application_properties_s.nextval,'application.loglevel','DEBUG','application loglevel');
