#!/usr/bin/env python

class Callable:
  
  def __init__(self):
    pass
      




