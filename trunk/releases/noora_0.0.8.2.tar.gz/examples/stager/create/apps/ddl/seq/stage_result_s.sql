create sequence stage_result_s
increment by 1
start with 1
nocycle
nocache
order
/
