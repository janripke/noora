create sequence sr_selection_s
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
nocache
order;
