create index LOG_JOB_NAME_IDX on LOG (JOB_NAME) tablespace TS_INDEX;
