#!/usr/bin/env python


class ProcessorResult:
    
  def __init__(self, result):
    self.__result = result
  
  def getResult(self):
    return self.__result
      
  
  




