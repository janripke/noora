-- feestdayen 2010
insert into holidays(day, year, description)
values(to_date('2010-01-01','yyyy-mm-dd'),'2010','Nieuwyear');
insert into holidays(day, year, description)
values(to_date('2010-04-04','yyyy-mm-dd'),'2010','1e Paasday');
insert into holidays(day, year, description)
values(to_date('2010-04-05','yyyy-mm-dd'),'2010','2e Paasday');
insert into holidays(day, year, description)
values(to_date('2010-04-30','yyyy-mm-dd'),'2010','Koninginneday');
insert into holidays(day, year, description)
values(to_date('2010-05-05','yyyy-mm-dd'),'2010','Bevrijdingsday');
insert into holidays(day, year, description)
values(to_date('2010-05-13','yyyy-mm-dd'),'2010','Hemelvaartday');
insert into holidays(day, year, description)
values(to_date('2010-05-23','yyyy-mm-dd'),'2010','1e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2010-05-24','yyyy-mm-dd'),'2010','2e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2010-12-25','yyyy-mm-dd'),'2010','1e Kerstday');
insert into holidays(day, year, description)
values(to_date('2010-12-26','yyyy-mm-dd'),'2010','2e Kerstday');
-- feestdayen 2011
insert into holidays(day, year, description)
values(to_date('2011-01-01','yyyy-mm-dd'),'2011','Nieuwyear');
insert into holidays(day, year, description)
values(to_date('2011-04-24','yyyy-mm-dd'),'2011','1e Paasday');
insert into holidays(day, year, description)
values(to_date('2011-04-25','yyyy-mm-dd'),'2011','2e Paasday');
insert into holidays(day, year, description)
values(to_date('2011-04-30','yyyy-mm-dd'),'2011','Koninginneday');
insert into holidays(day, year, description)
values(to_date('2011-06-02','yyyy-mm-dd'),'2011','Hemelvaartday');
insert into holidays(day, year, description)
values(to_date('2011-06-12','yyyy-mm-dd'),'2011','1e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2011-06-13','yyyy-mm-dd'),'2011','2e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2011-12-25','yyyy-mm-dd'),'2011','1e Kerstday');
insert into holidays(day, year, description)
values(to_date('2011-12-26','yyyy-mm-dd'),'2011','2e Kerstday');
-- feestdayen 2012
insert into holidays(day, year, description)
values(to_date('2012-01-01','yyyy-mm-dd'),'2012','Nieuwyear');
insert into holidays(day, year, description)
values(to_date('2012-04-08','yyyy-mm-dd'),'2012','1e Paasday');
insert into holidays(day, year, description)
values(to_date('2012-04-09','yyyy-mm-dd'),'2012','2e Paasday');
insert into holidays(day, year, description)
values(to_date('2012-04-30','yyyy-mm-dd'),'2012','Koninginneday');
insert into holidays(day, year, description)
values(to_date('2012-05-17','yyyy-mm-dd'),'2012','Hemelvaartday');
insert into holidays(day, year, description)
values(to_date('2012-05-27','yyyy-mm-dd'),'2012','1e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2012-05-28','yyyy-mm-dd'),'2012','2e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2012-12-25','yyyy-mm-dd'),'2012','1e Kerstday');
insert into holidays(day, year, description)
values(to_date('2012-12-26','yyyy-mm-dd'),'2012','2e Kerstday');
-- feestdayen 2013
insert into holidays(day, year, description)
values(to_date('2013-01-01','yyyy-mm-dd'),'2013','Nieuwyear');
insert into holidays(day, year, description)
values(to_date('2013-03-31','yyyy-mm-dd'),'2013','1e Paasday');
insert into holidays(day, year, description)
values(to_date('2013-04-01','yyyy-mm-dd'),'2013','2e Paasday');
insert into holidays(day, year, description)
values(to_date('2013-04-30','yyyy-mm-dd'),'2013','Koninginneday');
insert into holidays(day, year, description)
values(to_date('2013-05-09','yyyy-mm-dd'),'2013','Hemelvaartday');
insert into holidays(day, year, description)
values(to_date('2013-05-19','yyyy-mm-dd'),'2013','1e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2013-05-20','yyyy-mm-dd'),'2013','2e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2013-12-25','yyyy-mm-dd'),'2013','1e Kerstday');
insert into holidays(day, year, description)
values(to_date('2013-12-26','yyyy-mm-dd'),'2013','2e Kerstday');
-- feestdayen 2014
insert into holidays(day, year, description)
values(to_date('2014-01-01','yyyy-mm-dd'),'2014','Nieuwyear');
insert into holidays(day, year, description)
values(to_date('2014-04-20','yyyy-mm-dd'),'2014','1e Paasday');
insert into holidays(day, year, description)
values(to_date('2014-04-21','yyyy-mm-dd'),'2014','2e Paasday');
insert into holidays(day, year, description)
values(to_date('2014-04-30','yyyy-mm-dd'),'2014','Koninginneday');
insert into holidays(day, year, description)
values(to_date('2014-05-29','yyyy-mm-dd'),'2014','Hemelvaartday');
insert into holidays(day, year, description)
values(to_date('2014-06-08','yyyy-mm-dd'),'2014','1e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2014-06-09','yyyy-mm-dd'),'2014','2e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2014-12-25','yyyy-mm-dd'),'2014','1e Kerstday');
insert into holidays(day, year, description)
values(to_date('2014-12-26','yyyy-mm-dd'),'2014','2e Kerstday');
-- feestdayen 2015
insert into holidays(day, year, description)
values(to_date('2015-01-01','yyyy-mm-dd'),'2015','Nieuwyear');
insert into holidays(day, year, description)
values(to_date('2015-04-05','yyyy-mm-dd'),'2015','1e Paasday');
insert into holidays(day, year, description)
values(to_date('2015-04-06','yyyy-mm-dd'),'2015','2e Paasday');
insert into holidays(day, year, description)
values(to_date('2015-04-30','yyyy-mm-dd'),'2015','Koninginneday');
insert into holidays(day, year, description)
values(to_date('2015-05-05','yyyy-mm-dd'),'2015','Bevrijdingsday');
insert into holidays(day, year, description)
values(to_date('2015-05-14','yyyy-mm-dd'),'2015','Hemelvaartday');
insert into holidays(day, year, description)
values(to_date('2015-05-24','yyyy-mm-dd'),'2015','1e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2015-05-25','yyyy-mm-dd'),'2015','2e Pinksterday');
insert into holidays(day, year, description)
values(to_date('2015-12-25','yyyy-mm-dd'),'2015','1e Kerstday');
insert into holidays(day, year, description)
values(to_date('2015-12-26','yyyy-mm-dd'),'2015','2e Kerstday');
