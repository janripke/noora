INSERT INTO `currencies` (currency) VALUES
('BTC'),
('satoshi'),
('uBTC'),
('mBTC');
