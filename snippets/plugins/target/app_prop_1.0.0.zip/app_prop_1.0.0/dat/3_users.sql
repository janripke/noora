INSERT INTO `users` (`id`, `grp_id`, `hashcode`, `username`, `password`, `email`, `bitcoin_address`, `referral_id`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 'be96a07ccb237c215bd8f1dc69fc649f', 'janripke', 'd97be7232be39d9d5e5674b535c2dbfe', 'janripke@gmail.com', '1PhwPZgV4uiWeJYbMsJrESZmiSwuJEcA8o', NULL, '2014-01-09 22:07:21', 'root@localhost', '2014-01-10 22:36:10', 'root@localhost'),
(2, 2, 'efab3520c7dbe3ea01d7165c7a6675f8', 'ineripke', 'a5ba6c8c4164243755c4d80a9209b7a6', 'ineripke@gmail.com', 'd', NULL, '2014-01-10 20:32:40', 'root@localhost', '2014-01-10 20:32:40', 'root@localhost'),
(3, 1, 'f930f828b0be5c5ebf7c9d0923ae4e34', 'eurotalker', 'bb0ed6ad56f41c6de469776171261226', 'eurotalker@gmail.com', '1AubDHogXT8iAdsydoDqkgNyxd3KMBFPed', NULL, '2014-01-10 23:04:07', 'root@localhost', '2014-01-11 00:06:45', 'root@localhost'),
(15, 2, '4b32525b6430b7f29850e061fedb9b84', 'demonny', '30ac45bdbbac75b19db52dee4d57fec3', 'jerryakan@gmail.com', '19r9PLFj2GSbvQeQFkXt4nRXv4xzmvx5jA', NULL, '2014-01-14 01:08:12', 'root@localhost', '2014-01-14 01:11:56', 'root@localhost');

