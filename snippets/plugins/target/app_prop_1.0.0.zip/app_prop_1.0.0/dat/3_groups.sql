INSERT INTO `groups` (`id`, `usergroup`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'administrator', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', ''),
(2, 'user', '0000-00-00 00:00:00', '', '0000-00-00 00:00:00', '');

