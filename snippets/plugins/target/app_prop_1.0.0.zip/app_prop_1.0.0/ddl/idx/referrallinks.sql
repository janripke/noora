CREATE INDEX rlk_ste_id_idx ON referrallinks (ste_id);
CREATE INDEX rlk_usr_id_idx ON referrallinks (usr_id);