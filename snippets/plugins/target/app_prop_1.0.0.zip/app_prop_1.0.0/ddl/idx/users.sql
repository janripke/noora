CREATE INDEX usr_grp_id_idx ON users (grp_id);
CREATE INDEX usr_referral_id_idx ON users (referral_id);