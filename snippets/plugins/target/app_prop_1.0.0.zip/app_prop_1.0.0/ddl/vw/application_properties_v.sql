CREATE VIEW application_properties_v AS 
SELECT id, name, value, description FROM application_properties;