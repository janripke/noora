create sequence APPLICATION_PROPERTIES_S
minvalue 1
maxvalue 999999999999
start with 1
increment by 1
nocache;
