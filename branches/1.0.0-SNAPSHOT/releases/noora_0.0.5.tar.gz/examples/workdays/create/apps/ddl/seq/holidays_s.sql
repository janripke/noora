-- Create sequence 
create sequence HOLIDAYS_S
minvalue 1
maxvalue 9999999999999999999999999999
start with 1
increment by 1
nocache
order;
