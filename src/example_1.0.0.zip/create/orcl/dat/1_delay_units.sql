
INSERT INTO delay_units (delay_unit) VALUES
('MIN'),
('HOUR');