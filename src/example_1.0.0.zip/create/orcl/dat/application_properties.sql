insert into application_properties(name,value) values ('application.domain.name','www.wriggler.nl');
